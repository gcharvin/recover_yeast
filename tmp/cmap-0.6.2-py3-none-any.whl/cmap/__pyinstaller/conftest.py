import os

os.environ["PYI_BUILDER_CLEANUP"] = "0"
from PyInstaller.utils.conftest import *  # noqa
