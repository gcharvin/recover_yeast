"""cmocean color maps.

https://matplotlib.org/cmocean/
https://github.com/matplotlib/cmocean
"""
