__all__ = ["MDI6"]
__version__ = "6.9.96"

from .mdi6 import MDI6
