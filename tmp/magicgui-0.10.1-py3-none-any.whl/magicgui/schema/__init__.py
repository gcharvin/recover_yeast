"""Module for defining the schema of a magicgui widget."""
