from napari._app_model._app import get_app_model

__all__ = ['get_app_model']
