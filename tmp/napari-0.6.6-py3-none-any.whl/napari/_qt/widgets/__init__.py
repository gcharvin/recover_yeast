"""Custom widgets that inherit from QWidget."""
