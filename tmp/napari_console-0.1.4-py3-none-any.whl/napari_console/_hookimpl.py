from .qt_console import QtConsole

# Wait to use hook impl
# @napari_hook_implementation
# def napari_experimental_provide_dock_widget():
#     return (QtConsole, {'area': 'bottom'})
