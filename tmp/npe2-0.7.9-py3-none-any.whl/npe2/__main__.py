from npe2.cli import main

if __name__ == "__main__":
    main()
