"""Pre-commit hooks using numpydoc."""
