from enum import Enum

__NAMESPACE__ = "http://www.openmicroscopy.org/Schemas/OME/2016-06"


class Filament_Type(Enum):
    INCANDESCENT = "Incandescent"
    HALOGEN = "Halogen"
    OTHER = "Other"
