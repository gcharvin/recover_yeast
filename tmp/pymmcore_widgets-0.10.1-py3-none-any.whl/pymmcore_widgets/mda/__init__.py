"""MDA widgets."""

from ._core_mda import MDAWidget

__all__ = ["MDAWidget"]
